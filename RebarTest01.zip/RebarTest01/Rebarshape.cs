﻿


using System;
using System.IO;
using System.Collections;
using System.Windows;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Structure;
using System.Drawing;
using System.Globalization;

using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace Revit.Samples.CreateRebarShapeImage
{
    /// <summary>
    /// Implements the Revit add-in interface IExternalCommand
    /// </summary>
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    [Autodesk.Revit.Attributes.Journaling(Autodesk.Revit.Attributes.JournalingMode.NoCommandData)]
    public class Command : IExternalCommand
    {
        ExternalCommandData m_revit = null;    //store external command 存外部命令
        //string m_errorMessage = " ";           // store error message 存错误信息
        ArrayList m_walls = new ArrayList();   //store the wall of selected 存选择的墙
        const double precision = 0.0000001;   //store the precision 存精度   

        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit, ref string message, Autodesk.Revit.DB.ElementSet elements)
        {
            try
            {
                m_revit = revit;
                UIDocument uidoc = revit.Application.ActiveUIDocument;
                ICollection<ElementId> selectedIds = uidoc.Selection.GetElementIds();

                string info = "Selected elements:\n";
                foreach (ElementId id in selectedIds)
                {
                    Element elem = uidoc.Document.GetElement(id);
                    info += "type->" + elem.GetType().ToString() + "\n";
                    info += "name->" + elem.Name + "\n";
                    Rebar bar = elem as Rebar;

                    if (bar != null)
                    {
                        IList<Subelement> elem2 = bar.GetSubelements();
                        //info+="Subelement->counts="+elem2.Count.ToString()+"\n";

                        RebarShape rebshape = uidoc.Document.GetElement(bar.GetShapeId()) as RebarShape;
                        ParameterSet para = bar.Parameters;
                        Parameter dm = bar.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER);

                        if (rebshape != null)
                        {
                            //钢筋形状线，用这个绘制Bitmap
                            Bitmap bmp = new Bitmap(50 * 4 * 2, 50 * 4 * 2);
                            Pen pen = new Pen(System.Drawing.Color.Black, 4);
                            Font myFont = new Font("宋体", 10, FontStyle.Bold);
                            Brush bush = new SolidBrush(System.Drawing.Color.Black);//填充的颜色
                            NumberFormatInfo m_nfi = new NumberFormatInfo();

                            //m_nfi = new CultureInfo("de-DE", false).NumberFormat;
                            m_nfi.NumberDecimalSeparator = ".";
                            m_nfi.NumberDecimalDigits = 0;
                            m_nfi.NumberGroupSeparator = "";
                            Graphics ht = Graphics.FromImage(bmp);
                            PointF pt1 = new PointF(0, 0), pt2 = new PointF(0, 0);
                            PointF pt1_r = new PointF(0, 0), pt2_r = new PointF(0, 0);
                            //获取长度
                            IList<Curve> rlines = bar.GetShapeDrivenAccessor().ComputeDrivingCurves();
                            List<double> linelengths = new List<double>();
                            int i = 0;
                            double reallen = 0.0;
                            foreach (Line line in rlines)
                            {
                                //计算实际长度，常量304.8

                                if ((i == 0) || (i == rlines.Count - 1))
                                {
                                    reallen = line.Length + 0.5 * dm.AsDouble();

                                }
                                else
                                {
                                    reallen = line.Length + dm.AsDouble();
                                }
                                reallen *= 304.8;
                                linelengths.Insert(i, reallen);

                                i++;
                            }
                            IList<Curve> lines = rebshape.GetCurvesForBrowser();
                            i = 0;
                            foreach (Line line in lines)
                            {
                                IList<XYZ> xyzs = line.Tessellate();
                                //info += "\nline.Length=" + line.Length*25.4;
                                //info += "\npt1=" + xyzs[0].ToString();
                                //info += "\npt2=" + xyzs[1].ToString();
                                //移轴，防止出现负的坐标
                                pt1.X = (float)(xyzs[0].X * 25.4 + 200);
                                pt1.Y = (float)(xyzs[0].Y * 25.4 + 200);
                                pt2.X = (float)(xyzs[1].X * 25.4 + 200);
                                pt2.Y = (float)(xyzs[1].Y * 25.4 + 200);
                                double jiaodu = 0;
                                ht.DrawLine(pen, pt1, pt2);
                                bmp.Save("D:\\" + i.ToString() + "_1.bmp");
                                //计算旋转后的坐标
                                //1.算直线角度
                                double k = 0;
                                if (pt1.X != pt2.X)
                                {
                                    k = (pt2.Y - pt1.Y) / (pt2.X - pt1.X);
                                    jiaodu = Math.Atan(k) / Math.PI * 180;
                                }
                                else { if (pt1.Y < pt2.Y) jiaodu = 90; else jiaodu = -90; }
                                if (jiaodu != 0)
                                {
                                    //如果角度不为零，以图片中心为旋转轴
                                    pt1_r.X = (float)(xyzs[0].X * 25.4) * (float)Math.Cos(jiaodu / 180 * Math.PI) + (float)(xyzs[0].Y * 25.4) * (float)Math.Sin(jiaodu / 180 * Math.PI) + 200;
                                    pt1_r.Y = -(float)(xyzs[0].X * 25.4) * (float)Math.Sin(jiaodu / 180 * Math.PI) + (float)(xyzs[0].Y * 25.4) * (float)Math.Cos(jiaodu / 180 * Math.PI) + 200;

                                    //旋转写文字
                                    bmp = KiRotate(bmp, (float)jiaodu, System.Drawing.Color.Transparent);
                                    ht = Graphics.FromImage(bmp);
                                    ht.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;//指定文本呈现的质量 解决文字锯齿问题
                                    ht.DrawString(linelengths[i].ToString("F", m_nfi), myFont, bush, pt1_r);
                                    bmp.Save("D:\\" + i.ToString() + "_2.bmp");
                                    //旋转回来
                                    bmp = KiRotate(bmp, -(float)jiaodu, System.Drawing.Color.Transparent);
                                    ht = Graphics.FromImage(bmp);
                                    bmp.Save("D:\\" + i.ToString() + "_3.bmp");
                                }
                                else
                                {
                                    ht.DrawString(linelengths[i].ToString("F", m_nfi), myFont, bush, pt1);
                                    //ht.DrawString(linelengths[i].ToString("F", m_nfi), myFont, bush, pt2);
                                    bmp.Save("D:\\" + i.ToString() + "_2.bmp");
                                }

                                //
                                i++;

                            }
                            bmp.Save("D:\\00.bmp");



                        }
                    }
                }

                TaskDialog.Show("Revit", info);
                return Autodesk.Revit.UI.Result.Succeeded;

            }
            catch (Exception e)
            {
                message = e.Message;
                return Autodesk.Revit.UI.Result.Failed;
            }
        }

        public static Bitmap KiRotate(Bitmap bmp, float angle, System.Drawing.Color bkColor)
        {
            int w = bmp.Width + 2;
            int h = bmp.Height + 2;

            PixelFormat pf;

            if (bkColor == System.Drawing.Color.Transparent)
            {
                pf = PixelFormat.Format32bppArgb;
            }
            else
            {
                pf = bmp.PixelFormat;
            }

            Bitmap tmp = new Bitmap(w, h, pf);
            Graphics g = Graphics.FromImage(tmp);
            g.Clear(bkColor);
            g.DrawImageUnscaled(bmp, 1, 1);
            g.Dispose();

            GraphicsPath path = new GraphicsPath();
            path.AddRectangle(new RectangleF(0f, 0f, w, h));
            Matrix mtrx = new Matrix();
            mtrx.Rotate(angle);
            RectangleF rct = path.GetBounds(mtrx);

            Bitmap dst = new Bitmap((int)rct.Width, (int)rct.Height, pf);
            g = Graphics.FromImage(dst);
            g.Clear(bkColor);
            g.TranslateTransform(-rct.X, -rct.Y);
            g.RotateTransform(angle);
            g.InterpolationMode = InterpolationMode.HighQualityBilinear;
            g.DrawImageUnscaled(tmp, 0, 0);
            g.Dispose();

            tmp.Dispose();

            return dst;
        }

        public static double ft2m(double val)
        {
            return UnitUtils.ConvertFromInternalUnits(val, DisplayUnitType.DUT_METERS);
        }




    }
}

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Autodesk.Revit.DB;
//using Autodesk.Revit.UI;
//using Autodesk.Revit.DB.Structure;


//namespace RebarTest01
//{
//    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
//    public class Class1:IExternalCommand
//    {
//        public Autodesk.Revit.UI.Result Execute(ExternalCommandData commandData, ref string message, ElementSet elments)
//        {
//            //TaskDialog.Show("Revit","Hello Word!");
//            try
//            {
//                // Select some elements in Revit before invoking this command 在执行命令前，选择某个对象
//                // Get the handle of current document. 获取当前文档句柄
//                UIDocument uidoc = commandData.Application.ActiveUIDocument;

//                /*
//                // Get the element selection of current document. 获取当前文档对象集合
//                Autodesk.Revit.UI.Selection.Selection selection  =     uidoc.Selection;
//                ICollection<ElementId> selectedIds =     uidoc.Selection.GetElementIds();

//                if (0 == selectedIds.Count)
//                {
//                    // If no elements selected.如果没有选择对象
//                    TaskDialog.Show("Revit","You haven't selected any elements.");
//                }
//                else
//                {
//                    String info = "Ids of selected elements in the document are: ";
//                    foreach (ElementId id in selectedIds)
//                    {
//                       info += "\n\t" + id.IntegerValue;//对象id
//                    }

//                    TaskDialog.Show("Revit",info);
//                }
//                /////////////////////////////////////////////////////////////////////////////
//                */

//                Autodesk.Revit.UI.Selection.Selection choices = uidoc.Selection;
//                Reference hasPickOne = choices.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element);
//                if (hasPickOne != null)
//                {
//                    //TaskDialog.Show("Revit", "One element selected.");
//                    String tishi="";
//                    Element elements = uidoc.Document.GetElement(hasPickOne.ElementId);
//                    // tishi=elements.GetType().ToString();
//                    //TaskDialog.Show("Revit",tishi);
//                    Rebar bar = elements as Rebar;
//                    if (bar!=null)
//                    { 
//                     BuiltInParameter paraIndex=BuiltInParameter.REBAR_BAR_DIAMETER;
//                     Parameter param = bar.get_Parameter(paraIndex);
//                     tishi ="REBAR_NUMBER:"+bar.get_Parameter(BuiltInParameter.REBAR_NUMBER).AsInteger().ToString()+"\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_SHAPE)!=null) tishi = tishi + "REBAR_SHAPE:" + bar.get_Parameter(BuiltInParameter.REBAR_SHAPE).AsString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_ALLOWED_BAR_TYPES) != null) tishi = tishi + "REBAR_BAR_ALLOWED_BAR_TYPES:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_ALLOWED_BAR_TYPES).AsInteger().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_DEFORMATION_TYPE) != null) tishi = tishi + "REBAR_BAR_DEFORMATION_TYPE:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_DEFORMATION_TYPE).AsInteger().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER) != null) tishi = tishi + "REBAR_BAR_DIAMETER:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER).AsDouble().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_HOOK_LENGTHS) != null) tishi = tishi + "REBAR_BAR_HOOK_LENGTHS:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_HOOK_LENGTHS).AsDouble().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_MAXIMUM_BEND_RADIUS) != null) tishi = tishi + "REBAR_BAR_MAXIMUM_BEND_RADIUS:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_MAXIMUM_BEND_RADIUS).AsDouble().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_STIRRUP_BEND_DIAMETER) != null) tishi = tishi + "REBAR_BAR_STIRRUP_BEND_DIAMETER:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_STIRRUP_BEND_DIAMETER).AsDouble().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_BAR_STYLE) != null) tishi = tishi + "REBAR_BAR_STYLE:" + bar.get_Parameter(BuiltInParameter.REBAR_BAR_STYLE).AsString().ToString() + "\n";

//                     if (bar.get_Parameter(BuiltInParameter.REBAR_CONTAINER_BAR_TYPE) != null) tishi = tishi + "REBAR_CONTAINER_BAR_TYPE:" + bar.get_Parameter(BuiltInParameter.REBAR_CONTAINER_BAR_TYPE).AsString().ToString() + "\n";
//                    //error if (bar.get_Parameter(BuiltInParameter.REBAR_DISTRIBUTION_TYPE) != null) tishi = tishi + "REBAR_DISTRIBUTION_TYPE:" + bar.get_Parameter(BuiltInParameter.REBAR_DISTRIBUTION_TYPE).AsString().ToString() + "\n";
//                    if (bar.get_Parameter(BuiltInParameter.REBAR_ELEM_BAR_SPACING) != null) tishi = tishi + "REBAR_ELEM_BAR_SPACING:" + bar.get_Parameter(BuiltInParameter.REBAR_ELEM_BAR_SPACING).AsDouble().ToString() + "\n";
//                     if (bar.get_Parameter(BuiltInParameter.REBAR_ELEM_LENGTH) != null) tishi = tishi + "REBAR_ELEM_LENGTH:" + bar.get_Parameter(BuiltInParameter.REBAR_ELEM_LENGTH).AsDouble().ToString() + "\n";
//                    if (bar.get_Parameter(BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH) != null) tishi = tishi + "REBAR_ELEM_TOTAL_LENGTH:" + bar.get_Parameter(BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH).AsDouble().ToString() + "\n";
//                    if (bar.get_Parameter(BuiltInParameter.REBAR_INSTANCE_BAR_DIAMETER) != null) tishi = tishi + "REBAR_INSTANCE_BAR_DIAMETER:" + bar.get_Parameter(BuiltInParameter.REBAR_INSTANCE_BAR_DIAMETER).AsDouble().ToString() + "\n";
                   

//                     TaskDialog.Show("Revit", tishi);
//                    }

//                }


//            }
//            catch (Exception e)
//            {
//                message = e.Message;
//                return Autodesk.Revit.UI.Result.Failed;
//            }

//            return Autodesk.Revit.UI.Result.Succeeded;
//        } 
//        }
       
//   // public Parameter FindWithBuiltinParameterID(Wall wall)
//   //{
//   //     //Use the WALL_BASE_OFFSET paramametId
//   //     //to get the base offset parameter of the wall.
//   //     BuiltInParameter paraIndex = BuiltInParameter.WALL_BASE_OFFSET;
//   //     Parameter parameter = wall.get_Parameter(paraIndex);
//   //     return parameter;
//   //}
//}
